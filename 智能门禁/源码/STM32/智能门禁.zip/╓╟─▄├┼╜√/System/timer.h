#ifndef __TIMER_H_
#define __TIMER_H_


void TIM_Int_Init(u16 arr,u16 psc);

#endif
