#include "stm32f10x.h"                  // Device header
#include "OLED.h"
#include "led.h"
#include "usart2.h"
#include "Delay.h"
#include "as608.h"
#include "uart.h"
#include "light.h"
#include "dht11.h"
#include "pwm.h"
#include "stdio.h"
#include "string.h"
#include "servos.h"
#include "infrared.h"
#include "bee.h"

extern uint8_t dat[5];//温湿度值
extern int da_flag;

extern int Receive_Flag;	



void SERVO_SetAngle(float Angle)
{
		PWM_Setcompare1_s(Angle / 180 *2000 + 500);
}

//录指纹
void Add_FR(void)
{
	u8 i=0,ensure ,processnum=0;
	while(1)
	{
		switch (processnum)
		{
			case 0:
				i++;
				ensure=PS_GetImage();
				if(ensure==0x00) 
				{
					ensure=PS_GenChar(CharBuffer1);//Éú³ÉÌØÕ÷
					if(ensure==0x00)
					{
						i=0;
						processnum=1;//Ìøµ½µÚ¶þ²½						
					}else ;	//失败			
				}else ;	//失败					
				break;
			
			case 1:
				i++;
				ensure=PS_GetImage();
				if(ensure==0x00) 
				{
					ensure=PS_GenChar(CharBuffer2);//Éú³ÉÌØÕ÷			
					if(ensure==0x00)
					{
						i=0;
						processnum=2;//Ìøµ½µÚÈý²½
					}else ;	//失败	
				}else ;	//失败	
				break;

			case 2:
				ensure=PS_Match();
				if(ensure==0x00) 
				{
					processnum=3;//Ìøµ½µÚËÄ²½
				}
				else 
				{
					i=0;
					processnum=0;//Ìø»ØµÚÒ»²½		
				}
				Delay_ms(1000);
				break;

			case 3:
				ensure=PS_RegModel();
				if(ensure==0x00) 
				{
					processnum=4;//Ìøµ½µÚÎå²½
				}
				else 
				{
					processnum=0;	//失败	
				}
				Delay_ms(1000);
				break;
				
			case 4:	
				ensure=PS_StoreChar(CharBuffer2,1);//´¢´æÄ£°å
				if(ensure==0x00) 
				{			
					Delay_ms(1500);//ÑÓÊ±ºóÇå³ýÏÔÊ¾	
					return ;
				}
				else{processnum=0;}					
				break;				
		}
		Delay_ms(800);
		if(i==5)//³¬¹ý5´ÎÃ»ÓÐ°´ÊÖÖ¸ÔòÍË³ö
		{
			break;	
		}				
	}
}



//刷指纹
void press_FR(void)
{
	SearchResult seach;
	u8 ensure;
	float  angle=0;
	ensure=PS_GetImage();
	if(ensure==0x00)//获取图像成功
	{	
		ensure=PS_GenChar(CharBuffer1);
		if(ensure==0x00) //生成特征成功
		{		
			ensure=PS_HighSpeedSearch(CharBuffer1,0,300,&seach);
			if(ensure==0x00)//搜索成功
			{				
				Usart_SendString(USART1,"openclock");
				for(angle = 0; angle < 180; angle++)
				{
					SERVO_SetAngle(angle);
					Delay_ms(5);
				}
			}
			else
			{
				Usart_SendString(USART1,"fingerno");
			}
	  }
		else
		{
			Usart_SendString(USART1,"fingerno");
		}
	}
	else
	{
		Usart_SendString(USART1,"fingerno");
	}		
}




void getth()
{
	DHT_Read();
	int m1 = dat[0];//H,小数点前
	int m2 = dat[1];//H,小数点后
	int m3 = dat[2];
	int m4 = dat[3];
	printf("T:%d.%d^C H:%d.%d%%\r\n",m3,m4,m1,m2);
}




int main(void)
{
	LED_Init();
	OLED_Init();
	uart_init();
	uart2_init();
	AD_Init();
	//PWM_Init();
	SERVER_Init();
	Bee_Init();
	float  angle=0;
	uint32_t ADvalue1 =0;
	int infrared=0;
	char a[10];
	PS_StaGPIO_Init();
	while(PS_HandShake(&AS608Addr))//与AS608模块握手
	{
		Delay_ms(1000);  
	}
	//连接模块成功
	while(1)
	{
		ADvalue1 = Get_ADValue(ADC_Channel_3);
		//OLED_ShowNum(2,5, ADvalue1,4);		//0-4000波动，越亮越小，正常1400-2000
		int x = 100-ADvalue1/40 ;
		OLED_ShowString(1,1,"  Daytime Mode  ");
		OLED_ShowString(2,1,"  Light ");
		if(x>=100)
		{
			x=0;
		}
		if(x<=0)
		{
			x=99;
		}
		OLED_ShowNum(2,9, x,2);
		OLED_ShowString(2,11,"%");
		getth();
		if(x<=35)
		{
			LED1_On();
		}
		else
		{
			LED1_Off();
		}
		if(Receive_Flag == 1)						//接收数据标志位等于1（接收完毕，停止接收）
		{
			Receive_Flag = 0;
			strcpy(a,USART_ReceiveString);
			memset(USART_ReceiveString,0,10);
			if(strcmp(a,"aa") == 0)
			{
				OLED_ShowString(1,1,"Fingerprint Mode");
				//程序待添加，指纹识别成功后发送串口消息
				while(1)
				{
					OLED_ShowString(3,1,"Fingerprint Wait");
					if(PS_Sta == 1)
					{
						press_FR();
						break;
					}
				}
				OLED_ShowString(3,1,"                 ");
			}
			else if(strcmp(a,"bb") == 0)
			{
				//printf("密码开锁\r\n");
				OLED_ShowString(1,1," Password Mode  ");
				for(angle = 0; angle < 180; angle++)
				{
					SERVO_SetAngle(angle);
					Delay_ms(5);
				}
			}
			else if(strcmp(a,"cc") == 0)
			{
				for(angle = 180; angle > 0; angle--)
				{
					SERVO_SetAngle(angle);
					Delay_ms(5);
				}
			}
			else if(strcmp(a,"dd") == 0)
			{
				OLED_ShowString(1,1,"   Night Mode    ");
				while(da_flag == 1)
				{
					if(infrared >= 4)
					{
						Usart_SendString(USART1,"havepeople");
						for(int i = 0;i<15;i++)
						{
							Bee_On();
							Delay_ms(150);
							Bee_Off();
							Delay_ms(150);
						}				
						infrared=0;
						OLED_ShowString(4,1,"   ");
					}
					if(check_flag == 1)
					{
						OLED_ShowString(1,1,"  Night Normal  ");
						
					}
					else if(check_flag == 0)
					{
						//有人
						infrared++;
						OLED_ShowString(1,1,"  Night Alarm   ");
						OLED_ShowNum(4,2, infrared,1);
						Bee_On();
						Delay_ms(150);
						Bee_Off();
					}
				}
				OLED_ShowString(4,1,"   ");
			}
		}
	}
}


