#include "stm32f10x.h"
#include "stdio.h"
#include "string.h"
#include "uart.h"

void uart_init()
{
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_USART1,ENABLE);
	
	GPIO_InitTypeDef GPIO_InitStruct;
	//tx
	GPIO_InitStruct.GPIO_Mode = GPIO_Mode_AF_PP;
	GPIO_InitStruct.GPIO_Pin = GPIO_Pin_9;             
	GPIO_InitStruct.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOA, &GPIO_InitStruct);
	//rx
	GPIO_InitStruct.GPIO_Mode = GPIO_Mode_IN_FLOATING;
	GPIO_InitStruct.GPIO_Pin = GPIO_Pin_10;             
	GPIO_InitStruct.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOA, &GPIO_InitStruct);
	
	NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);
	NVIC_InitTypeDef NVIC_InitStructure;
	NVIC_InitStructure.NVIC_IRQChannel = USART1_IRQn;
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority=3 ;
	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 3;
	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
	NVIC_Init(&NVIC_InitStructure);

	
	USART_InitTypeDef USART_InitStruct;
	USART_InitStruct.USART_BaudRate = 115200;
	USART_InitStruct.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
	USART_InitStruct.USART_Mode = USART_Mode_Rx | USART_Mode_Tx;
	USART_InitStruct.USART_Parity = USART_Parity_No;
	USART_InitStruct.USART_StopBits = USART_StopBits_1;
	USART_InitStruct.USART_WordLength = USART_WordLength_8b;
	
	USART_Init(USART1,&USART_InitStruct);
	USART_ITConfig(USART1, USART_IT_RXNE, ENABLE);
	USART_ITConfig(USART1, USART_IT_IDLE, ENABLE);
	USART_Cmd(USART1, ENABLE);
}

//����һ�ֽ�
void Usart_SendByte( USART_TypeDef * pUSARTx, uint8_t ch)
{
	USART_SendData(pUSARTx,ch);
	while (USART_GetFlagStatus(pUSARTx, USART_FLAG_TXE) == RESET);	
}


//�����ַ���
void Usart_SendString( USART_TypeDef * pUSARTx, char *str)
{
	unsigned int k=0;
  do 
  {
      Usart_SendByte( pUSARTx, *(str + k) );
      k++;
  } while(*(str + k)!='\0');
  while(USART_GetFlagStatus(pUSARTx,USART_FLAG_TC)==RESET)
  {}
}


char USART_ReceiveString[10];		//�����յ��ַ���
int Receive_Flag = 0;						//���ձ�־λ
int Receive_sum = 0;						//�����±�
int  da_flag = 0;
void USART1_IRQHandler(void)
{
	/*
	uint8_t data;
	if(USART_GetITStatus(USART1,USART_IT_RXNE) == SET) //�����˽����ж�
	{
		data = USART_ReceiveData(USART1);			//��data������յ�����
		
		if ((readReg & 0X8000) == 0) 		//����δ���
		{
			if((readReg & 0X4000))	//�Ƿ���յ���0x0d
			{
			  if (data == '\n')		
				{
					readReg |= 0X8000;					
				}
				else 
				{
					readReg = 0;	
				}				
			}
			else 
			{
				if (data == '\r') 
				{
					readReg |= 0X4000;				
				}
				else 
				{
					readBuf[(readReg & 0X3fff)] = data;
					readReg++;					
					if ((readReg & 0X3fff) > READSIZE-1) 
					{
						readReg = 0;						
					}
				}			
			}		
		}
	}
	*/
	uint8_t temp;
	if(USART_GetITStatus(USART1,USART_IT_RXNE) == 1)		
	{
		USART_ReceiveString[Receive_sum++] = USART_ReceiveData(USART1);
		if(Receive_sum>49)
		{
			Receive_sum=0;
		}
		USART_ClearITPendingBit(USART1,USART_IT_RXNE);
	}
	if(USART_GetITStatus(USART1,USART_IT_IDLE) == 1)		
	{
		temp = USART1->SR;
		temp = USART1->DR;
		Receive_Flag = 1;
		Receive_sum=0;
	}
	if(strcmp(USART_ReceiveString,"dd") == 0)
	{
		da_flag = 1;
	}
	if (strcmp(USART_ReceiveString,"ee") == 0)
	{
		da_flag = 0;
	}
}

#if 1
//������ʹ�ð�������
//��׼����Ҫ��֧�ֺ��� 
//��׼��Ĭ������豸����ʾ�����ض���Ϊled�򴮿���
#pragma import(__use_no_semihosting)             

//�ļ��ṹ
struct __FILE 
{ 
	int handle; 
}; 

FILE __stdout;       
//�⺯��--�˳�����������_sys_exit()�Ա���ʹ�ð�����ģʽ    
void _sys_exit(int x) 
{ 
	x = x; 
}
//�ض���ʹ��printf
int fputc(int ch, FILE *f)
{
	USART_SendData(USART1, (uint8_t) ch);
	while (USART_GetFlagStatus(USART1, USART_FLAG_TXE) == RESET);		
	return (ch);
}
//�ض���ʹ��getchar
int fgetc(FILE *f)
{
	while (USART_GetFlagStatus(USART1, USART_FLAG_RXNE) == RESET);
	return (int)USART_ReceiveData(USART1);
}
#endif
