#ifndef __RGB_H_
#define __RGB_H_


void rgb_init(void);
void Led_PWM_Init(u16 arr,u16 psc);
void RGBLed(u8 R,u8 G,u8 B);

#endif
