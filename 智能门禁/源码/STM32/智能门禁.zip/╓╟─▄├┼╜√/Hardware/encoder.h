#ifndef __ENCODER_H_
#define __ENCODER_H_

void ENCODER_Init(void);
int16_t ENCODER_Get(void);

#endif

