#ifndef __SERVOS_H_
#define __SERVOS_H_


void SERVER_Init(void);
void PWM_Setcompare1_s(uint16_t Compare1);
    
#endif
