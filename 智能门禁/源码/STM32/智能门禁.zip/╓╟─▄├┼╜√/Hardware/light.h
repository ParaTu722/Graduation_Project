#ifndef __LIGHT_H_
#define __LIGHT_H_


void AD_Init(void);
uint16_t Get_ADValue(uint8_t ADC_Channel);

#endif
