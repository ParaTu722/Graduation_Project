#include "stm32f10x.h"


void rgb_init()
{

	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB, ENABLE);   //??GPIOA
	
	GPIO_InitTypeDef GPIO_InitStruct;
	GPIO_InitStruct.GPIO_Mode = GPIO_Mode_Out_PP;   //????(??????????)
	GPIO_InitStruct.GPIO_Pin = GPIO_Pin_13 | GPIO_Pin_14|GPIO_Pin_15;             
	GPIO_InitStruct.GPIO_Speed = GPIO_Speed_50MHz;  //?????50MHZ???
	GPIO_Init(GPIOB, &GPIO_InitStruct);             //???GPIO

}

void Led_PWM_Init(u16 arr,u16 psc)
{
	TIM_TimeBaseInitTypeDef TIM_TimeBaseStructure;
	TIM_OCInitTypeDef       TIM_OCInitStructure;
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_TIM1, ENABLE);   
	rgb_init();
	TIM_DeInit(TIM1);

	TIM_TimeBaseStructure.TIM_Period            = arr;
	TIM_TimeBaseStructure.TIM_Prescaler         = psc;
	TIM_TimeBaseStructure.TIM_CounterMode       = TIM_CounterMode_Up;
	TIM_TimeBaseStructure.TIM_ClockDivision     = 0;
	TIM_TimeBaseStructure.TIM_RepetitionCounter = 0;
	TIM_TimeBaseInit(TIM2, &TIM_TimeBaseStructure);

	//pwmģʽ����
	TIM_OCInitStructure.TIM_OCMode             = TIM_OCMode_PWM2;
	TIM_OCInitStructure.TIM_OutputState        = TIM_OutputState_Enable;  
	TIM_OCInitStructure.TIM_Pulse                   = 0; 
	TIM_OCInitStructure.TIM_OCPolarity = TIM_OCPolarity_High;
	
	TIM_OC1Init(TIM1, &TIM_OCInitStructure);
	TIM_OC2Init(TIM1, &TIM_OCInitStructure);
	TIM_OC3Init(TIM1, &TIM_OCInitStructure);
	
	TIM_OC1PreloadConfig(TIM1, TIM_OCPreload_Enable);
	TIM_OC2PreloadConfig(TIM1, TIM_OCPreload_Enable);
	TIM_OC3PreloadConfig(TIM1, TIM_OCPreload_Enable);
	
	TIM_CtrlPWMOutputs(TIM1, ENABLE);
	
	TIM_ARRPreloadConfig(TIM1, ENABLE);
	TIM_Cmd(TIM1, ENABLE);
}

void  RGBLed(u8 R,u8 G,u8 B)
{
    TIM_SetCompare1(TIM1,R);           //CH1 R
    TIM_SetCompare2(TIM1,G);        //CH2 G
    TIM_SetCompare3(TIM1,B);           //CH3 B
}

