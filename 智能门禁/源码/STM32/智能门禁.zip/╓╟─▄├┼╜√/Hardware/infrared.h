#ifndef __INFRARED_H_
#define __INFRARED_H_

#include "stm32f10x.h" 

#define	check_flag	GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_0)

void Infrared_Init(void);

#endif
