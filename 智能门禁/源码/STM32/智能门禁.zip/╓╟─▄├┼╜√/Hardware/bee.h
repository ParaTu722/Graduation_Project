#ifndef __BEE_H_
#define __BEE_H_

void Bee_Init(void);
void Bee_On(void);
void Bee_Off(void);
void Bee_Turn(void);
#endif

