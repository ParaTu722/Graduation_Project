#ifndef __LED_H_
#define __LED_H_

void LED_Init(void);
void LED1_On(void);
void LED1_Off(void);

#endif
