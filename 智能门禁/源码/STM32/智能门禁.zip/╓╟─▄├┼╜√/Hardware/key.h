#ifndef __KEY_H_
#define __KEY_H_

void KEY_Init(void);
uint8_t KEY_GetNum(void);

#endif
