/********************************************************************************
** Form generated from reading UI file 'uart.ui'
**
** Created by: Qt User Interface Compiler version 5.15.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_UART_H
#define UI_UART_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_uart
{
public:
    QWidget *centralwidget;
    QHBoxLayout *horizontalLayout_2;
    QSpacerItem *horizontalSpacer_2;
    QHBoxLayout *horizontalLayout;
    QPushButton *pushButton;
    QSpacerItem *horizontalSpacer;
    QComboBox *comboBox;
    QSpacerItem *horizontalSpacer_3;
    QMenuBar *menubar;
    QStatusBar *statusbar;

    void setupUi(QMainWindow *uart)
    {
        if (uart->objectName().isEmpty())
            uart->setObjectName(QString::fromUtf8("uart"));
        uart->resize(400, 200);
        uart->setStyleSheet(QString::fromUtf8("#uart{\n"
"border-image: url(:/image/ui_bj2.png);\n"
"}"));
        centralwidget = new QWidget(uart);
        centralwidget->setObjectName(QString::fromUtf8("centralwidget"));
        horizontalLayout_2 = new QHBoxLayout(centralwidget);
        horizontalLayout_2->setObjectName(QString::fromUtf8("horizontalLayout_2"));
        horizontalSpacer_2 = new QSpacerItem(73, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_2->addItem(horizontalSpacer_2);

        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        pushButton = new QPushButton(centralwidget);
        pushButton->setObjectName(QString::fromUtf8("pushButton"));
        pushButton->setMinimumSize(QSize(70, 70));
        pushButton->setMaximumSize(QSize(70, 70));
        pushButton->setStyleSheet(QString::fromUtf8("background:transparent;\n"
"color: rgb(255, 255, 255);"));

        horizontalLayout->addWidget(pushButton);

        horizontalSpacer = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout->addItem(horizontalSpacer);

        comboBox = new QComboBox(centralwidget);
        comboBox->addItem(QString());
        comboBox->addItem(QString());
        comboBox->addItem(QString());
        comboBox->addItem(QString());
        comboBox->addItem(QString());
        comboBox->addItem(QString());
        comboBox->addItem(QString());
        comboBox->addItem(QString());
        comboBox->addItem(QString());
        comboBox->addItem(QString());
        comboBox->setObjectName(QString::fromUtf8("comboBox"));
        comboBox->setMinimumSize(QSize(153, 40));
        comboBox->setMaximumSize(QSize(153, 40));
        QFont font;
        font.setPointSize(14);
        font.setBold(true);
        font.setWeight(75);
        comboBox->setFont(font);
        comboBox->setStyleSheet(QString::fromUtf8("background:transparent;\n"
"color: rgb(255, 255, 255);"));

        horizontalLayout->addWidget(comboBox);


        horizontalLayout_2->addLayout(horizontalLayout);

        horizontalSpacer_3 = new QSpacerItem(72, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_2->addItem(horizontalSpacer_3);

        uart->setCentralWidget(centralwidget);
        menubar = new QMenuBar(uart);
        menubar->setObjectName(QString::fromUtf8("menubar"));
        menubar->setGeometry(QRect(0, 0, 400, 17));
        uart->setMenuBar(menubar);
        statusbar = new QStatusBar(uart);
        statusbar->setObjectName(QString::fromUtf8("statusbar"));
        uart->setStatusBar(statusbar);

        retranslateUi(uart);

        QMetaObject::connectSlotsByName(uart);
    } // setupUi

    void retranslateUi(QMainWindow *uart)
    {
        uart->setWindowTitle(QCoreApplication::translate("uart", "MainWindow", nullptr));
        pushButton->setText(QString());
        comboBox->setItemText(0, QCoreApplication::translate("uart", "\351\200\232\350\256\257\351\200\211\346\213\251", nullptr));
        comboBox->setItemText(1, QCoreApplication::translate("uart", "COM1", nullptr));
        comboBox->setItemText(2, QCoreApplication::translate("uart", "COM2", nullptr));
        comboBox->setItemText(3, QCoreApplication::translate("uart", "COM3", nullptr));
        comboBox->setItemText(4, QCoreApplication::translate("uart", "COM4", nullptr));
        comboBox->setItemText(5, QCoreApplication::translate("uart", "COM5", nullptr));
        comboBox->setItemText(6, QCoreApplication::translate("uart", "COM6", nullptr));
        comboBox->setItemText(7, QCoreApplication::translate("uart", "COM7", nullptr));
        comboBox->setItemText(8, QCoreApplication::translate("uart", "COM8", nullptr));
        comboBox->setItemText(9, QCoreApplication::translate("uart", "COM9", nullptr));

    } // retranslateUi

};

namespace Ui {
    class uart: public Ui_uart {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_UART_H
