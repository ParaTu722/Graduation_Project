/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 5.15.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QCheckBox>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QLCDNumber>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QTabWidget>
#include <QtWidgets/QTextEdit>
#include <QtWidgets/QToolBar>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QWidget *centralWidget;
    QTabWidget *tabWidget;
    QWidget *tab_3;
    QWidget *widget;
    QWidget *layoutWidget;
    QVBoxLayout *verticalLayout_11;
    QHBoxLayout *horizontalLayout_10;
    QSpacerItem *horizontalSpacer_6;
    QHBoxLayout *horizontalLayout_6;
    QVBoxLayout *verticalLayout_7;
    QSpacerItem *verticalSpacer_3;
    QVBoxLayout *verticalLayout_5;
    QHBoxLayout *horizontalLayout_12;
    QPushButton *pushButton_12;
    QPushButton *pushButton_13;
    QSpacerItem *horizontalSpacer_8;
    QSpacerItem *verticalSpacer_5;
    QPushButton *pushButton_3;
    QSpacerItem *verticalSpacer;
    QVBoxLayout *verticalLayout_4;
    QPushButton *pushButton_11;
    QPushButton *pushButton_14;
    QPushButton *pushButton_5;
    QPushButton *pushButton_6;
    QPushButton *pushButton_7;
    QPushButton *pushButton_8;
    QVBoxLayout *verticalLayout_3;
    QLCDNumber *lcdNumber;
    QHBoxLayout *horizontalLayout_9;
    QSpacerItem *horizontalSpacer_12;
    QTextEdit *textEdit;
    QSpacerItem *horizontalSpacer_11;
    QHBoxLayout *horizontalLayout_4;
    QVBoxLayout *verticalLayout_2;
    QVBoxLayout *verticalLayout;
    QHBoxLayout *horizontalLayout_3;
    QSpacerItem *horizontalSpacer_5;
    QLineEdit *lineEdit;
    QSpacerItem *horizontalSpacer_4;
    QHBoxLayout *horizontalLayout_2;
    QSpacerItem *horizontalSpacer_3;
    QHBoxLayout *horizontalLayout;
    QPushButton *pushButton;
    QSpacerItem *horizontalSpacer_9;
    QPushButton *pushButton_2;
    QSpacerItem *horizontalSpacer;
    QPushButton *pushButton_15;
    QSpacerItem *horizontalSpacer_10;
    QVBoxLayout *verticalLayout_12;
    QHBoxLayout *horizontalLayout_13;
    QCheckBox *checkBox_2;
    QCheckBox *checkBox;
    QHBoxLayout *horizontalLayout_14;
    QCheckBox *checkBox_3;
    QCheckBox *checkBox_4;
    QSpacerItem *horizontalSpacer_2;
    QVBoxLayout *verticalLayout_10;
    QSpacerItem *verticalSpacer_2;
    QVBoxLayout *verticalLayout_6;
    QHBoxLayout *horizontalLayout_8;
    QHBoxLayout *horizontalLayout_7;
    QPushButton *pushButton_9;
    QHBoxLayout *horizontalLayout_5;
    QVBoxLayout *verticalLayout_8;
    QPushButton *pushButton_10;
    QHBoxLayout *horizontalLayout_11;
    QVBoxLayout *verticalLayout_9;
    QPushButton *pushButton_4;
    QSpacerItem *horizontalSpacer_7;
    QMenuBar *menuBar;
    QToolBar *mainToolBar;
    QStatusBar *statusBar;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QString::fromUtf8("MainWindow"));
        MainWindow->resize(1462, 657);
        QFont font;
        font.setPointSize(10);
        font.setBold(true);
        MainWindow->setFont(font);
        MainWindow->setStyleSheet(QString::fromUtf8("#MainWindow{\n"
"border-image: url(:/image/ui_bj2.png);\n"
"}"));
        MainWindow->setIconSize(QSize(20, 20));
        MainWindow->setTabShape(QTabWidget::Rounded);
        centralWidget = new QWidget(MainWindow);
        centralWidget->setObjectName(QString::fromUtf8("centralWidget"));
        tabWidget = new QTabWidget(centralWidget);
        tabWidget->setObjectName(QString::fromUtf8("tabWidget"));
        tabWidget->setGeometry(QRect(780, 0, 651, 441));
        tabWidget->setTabPosition(QTabWidget::North);
        tabWidget->setTabShape(QTabWidget::Triangular);
        tabWidget->setDocumentMode(false);
        tabWidget->setTabsClosable(false);
        tabWidget->setMovable(false);
        tabWidget->setTabBarAutoHide(true);
        tab_3 = new QWidget();
        tab_3->setObjectName(QString::fromUtf8("tab_3"));
        widget = new QWidget(tab_3);
        widget->setObjectName(QString::fromUtf8("widget"));
        widget->setGeometry(QRect(-31, -31, 721, 521));
        tabWidget->addTab(tab_3, QString());
        layoutWidget = new QWidget(centralWidget);
        layoutWidget->setObjectName(QString::fromUtf8("layoutWidget"));
        layoutWidget->setGeometry(QRect(0, 0, 782, 441));
        verticalLayout_11 = new QVBoxLayout(layoutWidget);
        verticalLayout_11->setSpacing(6);
        verticalLayout_11->setContentsMargins(11, 11, 11, 11);
        verticalLayout_11->setObjectName(QString::fromUtf8("verticalLayout_11"));
        verticalLayout_11->setContentsMargins(0, 0, 0, 0);
        horizontalLayout_10 = new QHBoxLayout();
        horizontalLayout_10->setSpacing(6);
        horizontalLayout_10->setObjectName(QString::fromUtf8("horizontalLayout_10"));
        horizontalSpacer_6 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_10->addItem(horizontalSpacer_6);

        horizontalLayout_6 = new QHBoxLayout();
        horizontalLayout_6->setSpacing(6);
        horizontalLayout_6->setObjectName(QString::fromUtf8("horizontalLayout_6"));
        verticalLayout_7 = new QVBoxLayout();
        verticalLayout_7->setSpacing(6);
        verticalLayout_7->setObjectName(QString::fromUtf8("verticalLayout_7"));
        verticalSpacer_3 = new QSpacerItem(20, 17, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout_7->addItem(verticalSpacer_3);

        verticalLayout_5 = new QVBoxLayout();
        verticalLayout_5->setSpacing(6);
        verticalLayout_5->setObjectName(QString::fromUtf8("verticalLayout_5"));
        horizontalLayout_12 = new QHBoxLayout();
        horizontalLayout_12->setSpacing(6);
        horizontalLayout_12->setObjectName(QString::fromUtf8("horizontalLayout_12"));
        pushButton_12 = new QPushButton(layoutWidget);
        pushButton_12->setObjectName(QString::fromUtf8("pushButton_12"));
        pushButton_12->setMinimumSize(QSize(40, 40));
        pushButton_12->setMaximumSize(QSize(40, 40));
        QFont font1;
        font1.setPointSize(12);
        font1.setBold(true);
        pushButton_12->setFont(font1);
        pushButton_12->setStyleSheet(QString::fromUtf8("background:transparent;"));

        horizontalLayout_12->addWidget(pushButton_12);

        pushButton_13 = new QPushButton(layoutWidget);
        pushButton_13->setObjectName(QString::fromUtf8("pushButton_13"));
        pushButton_13->setMinimumSize(QSize(40, 40));
        pushButton_13->setMaximumSize(QSize(40, 40));
        pushButton_13->setFont(font1);
        pushButton_13->setStyleSheet(QString::fromUtf8("background:transparent;"));

        horizontalLayout_12->addWidget(pushButton_13);

        horizontalSpacer_8 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_12->addItem(horizontalSpacer_8);


        verticalLayout_5->addLayout(horizontalLayout_12);

        verticalSpacer_5 = new QSpacerItem(48, 17, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout_5->addItem(verticalSpacer_5);

        pushButton_3 = new QPushButton(layoutWidget);
        pushButton_3->setObjectName(QString::fromUtf8("pushButton_3"));
        pushButton_3->setMinimumSize(QSize(135, 41));
        pushButton_3->setMaximumSize(QSize(135, 41));
        QFont font2;
        font2.setPointSize(16);
        font2.setBold(true);
        pushButton_3->setFont(font2);
        pushButton_3->setStyleSheet(QString::fromUtf8("background:transparent;\n"
"color: rgb(255, 255, 255);\n"
"qproperty-iconSize:35px;"));

        verticalLayout_5->addWidget(pushButton_3);

        verticalSpacer = new QSpacerItem(20, 18, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout_5->addItem(verticalSpacer);

        verticalLayout_4 = new QVBoxLayout();
        verticalLayout_4->setSpacing(6);
        verticalLayout_4->setObjectName(QString::fromUtf8("verticalLayout_4"));
        pushButton_11 = new QPushButton(layoutWidget);
        pushButton_11->setObjectName(QString::fromUtf8("pushButton_11"));
        pushButton_11->setMinimumSize(QSize(140, 41));
        pushButton_11->setMaximumSize(QSize(140, 41));
        QFont font3;
        font3.setPointSize(16);
        font3.setBold(true);
        font3.setItalic(false);
        pushButton_11->setFont(font3);
        pushButton_11->setContextMenuPolicy(Qt::DefaultContextMenu);
        pushButton_11->setStyleSheet(QString::fromUtf8("background:transparent;\n"
"color: rgb(255, 255, 255);\n"
"qproperty-iconSize:35px;"));

        verticalLayout_4->addWidget(pushButton_11);

        pushButton_14 = new QPushButton(layoutWidget);
        pushButton_14->setObjectName(QString::fromUtf8("pushButton_14"));
        pushButton_14->setMinimumSize(QSize(135, 41));
        pushButton_14->setMaximumSize(QSize(135, 41));
        pushButton_14->setFont(font2);
        pushButton_14->setStyleSheet(QString::fromUtf8("background:transparent;\n"
"color: rgb(255, 255, 255);"));

        verticalLayout_4->addWidget(pushButton_14);

        pushButton_5 = new QPushButton(layoutWidget);
        pushButton_5->setObjectName(QString::fromUtf8("pushButton_5"));
        pushButton_5->setMinimumSize(QSize(160, 41));
        pushButton_5->setMaximumSize(QSize(160, 41));
        pushButton_5->setFont(font2);
        pushButton_5->setStyleSheet(QString::fromUtf8("background:transparent;\n"
"color: rgb(255, 255, 255);"));

        verticalLayout_4->addWidget(pushButton_5);

        pushButton_6 = new QPushButton(layoutWidget);
        pushButton_6->setObjectName(QString::fromUtf8("pushButton_6"));
        pushButton_6->setMinimumSize(QSize(135, 41));
        pushButton_6->setMaximumSize(QSize(135, 41));
        pushButton_6->setFont(font2);
        pushButton_6->setStyleSheet(QString::fromUtf8("background:transparent;\n"
"color: rgb(255, 255, 255);"));

        verticalLayout_4->addWidget(pushButton_6);

        pushButton_7 = new QPushButton(layoutWidget);
        pushButton_7->setObjectName(QString::fromUtf8("pushButton_7"));
        pushButton_7->setMinimumSize(QSize(135, 41));
        pushButton_7->setMaximumSize(QSize(135, 41));
        pushButton_7->setFont(font2);
        pushButton_7->setStyleSheet(QString::fromUtf8("background:transparent;\n"
"color: rgb(255, 255, 255);"));

        verticalLayout_4->addWidget(pushButton_7);

        pushButton_8 = new QPushButton(layoutWidget);
        pushButton_8->setObjectName(QString::fromUtf8("pushButton_8"));
        pushButton_8->setMinimumSize(QSize(160, 41));
        pushButton_8->setMaximumSize(QSize(160, 41));
        pushButton_8->setFont(font2);
        pushButton_8->setStyleSheet(QString::fromUtf8("background:transparent;\n"
"color: rgb(255, 255, 255);"));

        verticalLayout_4->addWidget(pushButton_8);


        verticalLayout_5->addLayout(verticalLayout_4);


        verticalLayout_7->addLayout(verticalLayout_5);


        horizontalLayout_6->addLayout(verticalLayout_7);


        horizontalLayout_10->addLayout(horizontalLayout_6);

        verticalLayout_3 = new QVBoxLayout();
        verticalLayout_3->setSpacing(6);
        verticalLayout_3->setObjectName(QString::fromUtf8("verticalLayout_3"));
        lcdNumber = new QLCDNumber(layoutWidget);
        lcdNumber->setObjectName(QString::fromUtf8("lcdNumber"));
        lcdNumber->setMinimumSize(QSize(491, 65));
        QFont font4;
        font4.setPointSize(11);
        font4.setBold(true);
        lcdNumber->setFont(font4);
        lcdNumber->setCursor(QCursor(Qt::ArrowCursor));
        lcdNumber->setLayoutDirection(Qt::LeftToRight);
        lcdNumber->setStyleSheet(QString::fromUtf8("#lcdNumber{\n"
"border:none;background:transparent;\n"
"}"));
        lcdNumber->setDigitCount(19);
        lcdNumber->setSegmentStyle(QLCDNumber::Outline);
        lcdNumber->setProperty("intValue", QVariant(0));

        verticalLayout_3->addWidget(lcdNumber);

        horizontalLayout_9 = new QHBoxLayout();
        horizontalLayout_9->setSpacing(6);
        horizontalLayout_9->setObjectName(QString::fromUtf8("horizontalLayout_9"));
        horizontalSpacer_12 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_9->addItem(horizontalSpacer_12);

        textEdit = new QTextEdit(layoutWidget);
        textEdit->setObjectName(QString::fromUtf8("textEdit"));
        textEdit->setMinimumSize(QSize(400, 210));
        textEdit->setMaximumSize(QSize(400, 210));
        textEdit->setFont(font4);
        textEdit->setStyleSheet(QString::fromUtf8("color: rgb(213, 213, 213);"));
        textEdit->setFrameShape(QFrame::StyledPanel);

        horizontalLayout_9->addWidget(textEdit);

        horizontalSpacer_11 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_9->addItem(horizontalSpacer_11);


        verticalLayout_3->addLayout(horizontalLayout_9);

        horizontalLayout_4 = new QHBoxLayout();
        horizontalLayout_4->setSpacing(6);
        horizontalLayout_4->setObjectName(QString::fromUtf8("horizontalLayout_4"));
        verticalLayout_2 = new QVBoxLayout();
        verticalLayout_2->setSpacing(6);
        verticalLayout_2->setObjectName(QString::fromUtf8("verticalLayout_2"));
        verticalLayout = new QVBoxLayout();
        verticalLayout->setSpacing(6);
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        horizontalLayout_3 = new QHBoxLayout();
        horizontalLayout_3->setSpacing(6);
        horizontalLayout_3->setObjectName(QString::fromUtf8("horizontalLayout_3"));
        horizontalSpacer_5 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_3->addItem(horizontalSpacer_5);

        lineEdit = new QLineEdit(layoutWidget);
        lineEdit->setObjectName(QString::fromUtf8("lineEdit"));
        lineEdit->setMinimumSize(QSize(250, 30));
        lineEdit->setMaximumSize(QSize(250, 30));
        lineEdit->setFont(font1);
        lineEdit->setStyleSheet(QString::fromUtf8("color: rgb(213, 213, 213);\n"
"background:transparent;"));
        lineEdit->setEchoMode(QLineEdit::Normal);

        horizontalLayout_3->addWidget(lineEdit);

        horizontalSpacer_4 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_3->addItem(horizontalSpacer_4);


        verticalLayout->addLayout(horizontalLayout_3);

        horizontalLayout_2 = new QHBoxLayout();
        horizontalLayout_2->setSpacing(6);
        horizontalLayout_2->setObjectName(QString::fromUtf8("horizontalLayout_2"));
        horizontalSpacer_3 = new QSpacerItem(35, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_2->addItem(horizontalSpacer_3);

        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setSpacing(6);
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        pushButton = new QPushButton(layoutWidget);
        pushButton->setObjectName(QString::fromUtf8("pushButton"));
        pushButton->setEnabled(true);
        pushButton->setMinimumSize(QSize(50, 50));
        pushButton->setMaximumSize(QSize(50, 50));
        pushButton->setStyleSheet(QString::fromUtf8("border-image: url(:/image/uartsend.png);"));

        horizontalLayout->addWidget(pushButton);

        horizontalSpacer_9 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout->addItem(horizontalSpacer_9);

        pushButton_2 = new QPushButton(layoutWidget);
        pushButton_2->setObjectName(QString::fromUtf8("pushButton_2"));
        pushButton_2->setMinimumSize(QSize(50, 50));
        pushButton_2->setMaximumSize(QSize(50, 50));
        pushButton_2->setFocusPolicy(Qt::TabFocus);
        pushButton_2->setStyleSheet(QString::fromUtf8("border-image: url(:/image/refresh-modified.png);"));

        horizontalLayout->addWidget(pushButton_2);

        horizontalSpacer = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout->addItem(horizontalSpacer);

        pushButton_15 = new QPushButton(layoutWidget);
        pushButton_15->setObjectName(QString::fromUtf8("pushButton_15"));
        pushButton_15->setEnabled(true);
        pushButton_15->setMinimumSize(QSize(50, 50));
        pushButton_15->setMaximumSize(QSize(50, 50));
        pushButton_15->setStyleSheet(QString::fromUtf8("border-image: url(:/image/data_analyse.png);"));

        horizontalLayout->addWidget(pushButton_15);

        horizontalSpacer_10 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout->addItem(horizontalSpacer_10);


        horizontalLayout_2->addLayout(horizontalLayout);

        verticalLayout_12 = new QVBoxLayout();
        verticalLayout_12->setSpacing(6);
        verticalLayout_12->setObjectName(QString::fromUtf8("verticalLayout_12"));
        horizontalLayout_13 = new QHBoxLayout();
        horizontalLayout_13->setSpacing(6);
        horizontalLayout_13->setObjectName(QString::fromUtf8("horizontalLayout_13"));
        checkBox_2 = new QCheckBox(layoutWidget);
        checkBox_2->setObjectName(QString::fromUtf8("checkBox_2"));
        checkBox_2->setMinimumSize(QSize(30, 25));
        checkBox_2->setMaximumSize(QSize(30, 25));
        QFont font5;
        font5.setPointSize(14);
        font5.setBold(true);
        checkBox_2->setFont(font5);
        checkBox_2->setLayoutDirection(Qt::RightToLeft);
        checkBox_2->setStyleSheet(QString::fromUtf8("\n"
"color: rgb(255, 0, 0);"));
        checkBox_2->setIconSize(QSize(20, 20));

        horizontalLayout_13->addWidget(checkBox_2);

        checkBox = new QCheckBox(layoutWidget);
        checkBox->setObjectName(QString::fromUtf8("checkBox"));
        checkBox->setMinimumSize(QSize(30, 25));
        checkBox->setMaximumSize(QSize(30, 25));
        checkBox->setFont(font5);
        checkBox->setStyleSheet(QString::fromUtf8("color: rgb(0, 255, 0);"));
        checkBox->setIconSize(QSize(50, 16));

        horizontalLayout_13->addWidget(checkBox);


        verticalLayout_12->addLayout(horizontalLayout_13);

        horizontalLayout_14 = new QHBoxLayout();
        horizontalLayout_14->setSpacing(6);
        horizontalLayout_14->setObjectName(QString::fromUtf8("horizontalLayout_14"));
        checkBox_3 = new QCheckBox(layoutWidget);
        checkBox_3->setObjectName(QString::fromUtf8("checkBox_3"));
        checkBox_3->setMinimumSize(QSize(30, 25));
        checkBox_3->setMaximumSize(QSize(30, 25));
        checkBox_3->setFont(font5);
        checkBox_3->setLayoutDirection(Qt::RightToLeft);
        checkBox_3->setStyleSheet(QString::fromUtf8("color: rgb(248, 154, 194);"));
        checkBox_3->setIconSize(QSize(20, 20));

        horizontalLayout_14->addWidget(checkBox_3);

        checkBox_4 = new QCheckBox(layoutWidget);
        checkBox_4->setObjectName(QString::fromUtf8("checkBox_4"));
        checkBox_4->setMinimumSize(QSize(30, 25));
        checkBox_4->setMaximumSize(QSize(30, 25));
        checkBox_4->setFont(font5);
        checkBox_4->setMouseTracking(false);
        checkBox_4->setTabletTracking(false);
        checkBox_4->setLayoutDirection(Qt::LeftToRight);
        checkBox_4->setStyleSheet(QString::fromUtf8("color: rgb(255, 128, 0);"));
        checkBox_4->setIconSize(QSize(20, 20));

        horizontalLayout_14->addWidget(checkBox_4);


        verticalLayout_12->addLayout(horizontalLayout_14);


        horizontalLayout_2->addLayout(verticalLayout_12);

        horizontalSpacer_2 = new QSpacerItem(35, 17, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_2->addItem(horizontalSpacer_2);


        verticalLayout->addLayout(horizontalLayout_2);


        verticalLayout_2->addLayout(verticalLayout);


        horizontalLayout_4->addLayout(verticalLayout_2);


        verticalLayout_3->addLayout(horizontalLayout_4);


        horizontalLayout_10->addLayout(verticalLayout_3);

        verticalLayout_10 = new QVBoxLayout();
        verticalLayout_10->setSpacing(6);
        verticalLayout_10->setObjectName(QString::fromUtf8("verticalLayout_10"));
        verticalSpacer_2 = new QSpacerItem(17, 38, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout_10->addItem(verticalSpacer_2);

        verticalLayout_6 = new QVBoxLayout();
        verticalLayout_6->setSpacing(6);
        verticalLayout_6->setObjectName(QString::fromUtf8("verticalLayout_6"));
        horizontalLayout_8 = new QHBoxLayout();
        horizontalLayout_8->setSpacing(6);
        horizontalLayout_8->setObjectName(QString::fromUtf8("horizontalLayout_8"));
        horizontalLayout_7 = new QHBoxLayout();
        horizontalLayout_7->setSpacing(6);
        horizontalLayout_7->setObjectName(QString::fromUtf8("horizontalLayout_7"));
        pushButton_9 = new QPushButton(layoutWidget);
        pushButton_9->setObjectName(QString::fromUtf8("pushButton_9"));
        pushButton_9->setMinimumSize(QSize(85, 85));
        pushButton_9->setMaximumSize(QSize(85, 85));
        pushButton_9->setFont(font);
        pushButton_9->setStyleSheet(QString::fromUtf8("border-image: url(:/image/movie-modified.png);\n"
"color: rgb(255, 255, 255);"));

        horizontalLayout_7->addWidget(pushButton_9);


        horizontalLayout_8->addLayout(horizontalLayout_7);


        verticalLayout_6->addLayout(horizontalLayout_8);

        horizontalLayout_5 = new QHBoxLayout();
        horizontalLayout_5->setSpacing(6);
        horizontalLayout_5->setObjectName(QString::fromUtf8("horizontalLayout_5"));
        verticalLayout_8 = new QVBoxLayout();
        verticalLayout_8->setSpacing(6);
        verticalLayout_8->setObjectName(QString::fromUtf8("verticalLayout_8"));
        pushButton_10 = new QPushButton(layoutWidget);
        pushButton_10->setObjectName(QString::fromUtf8("pushButton_10"));
        pushButton_10->setMinimumSize(QSize(85, 85));
        pushButton_10->setMaximumSize(QSize(80, 80));
        pushButton_10->setStyleSheet(QString::fromUtf8("border-image: url(:/image/stop.png);"));

        verticalLayout_8->addWidget(pushButton_10);


        horizontalLayout_5->addLayout(verticalLayout_8);


        verticalLayout_6->addLayout(horizontalLayout_5);

        horizontalLayout_11 = new QHBoxLayout();
        horizontalLayout_11->setSpacing(6);
        horizontalLayout_11->setObjectName(QString::fromUtf8("horizontalLayout_11"));
        verticalLayout_9 = new QVBoxLayout();
        verticalLayout_9->setSpacing(6);
        verticalLayout_9->setObjectName(QString::fromUtf8("verticalLayout_9"));
        pushButton_4 = new QPushButton(layoutWidget);
        pushButton_4->setObjectName(QString::fromUtf8("pushButton_4"));
        pushButton_4->setMinimumSize(QSize(85, 85));
        pushButton_4->setMaximumSize(QSize(85, 85));
        QFont font6;
        font6.setPointSize(30);
        font6.setBold(true);
        pushButton_4->setFont(font6);
        pushButton_4->setStyleSheet(QString::fromUtf8("border-image: url(:/image/sos-modified.png);"));

        verticalLayout_9->addWidget(pushButton_4);


        horizontalLayout_11->addLayout(verticalLayout_9);


        verticalLayout_6->addLayout(horizontalLayout_11);


        verticalLayout_10->addLayout(verticalLayout_6);


        horizontalLayout_10->addLayout(verticalLayout_10);

        horizontalSpacer_7 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_10->addItem(horizontalSpacer_7);


        verticalLayout_11->addLayout(horizontalLayout_10);

        MainWindow->setCentralWidget(centralWidget);
        menuBar = new QMenuBar(MainWindow);
        menuBar->setObjectName(QString::fromUtf8("menuBar"));
        menuBar->setGeometry(QRect(0, 0, 1462, 22));
        MainWindow->setMenuBar(menuBar);
        mainToolBar = new QToolBar(MainWindow);
        mainToolBar->setObjectName(QString::fromUtf8("mainToolBar"));
        MainWindow->addToolBar(Qt::TopToolBarArea, mainToolBar);
        statusBar = new QStatusBar(MainWindow);
        statusBar->setObjectName(QString::fromUtf8("statusBar"));
        MainWindow->setStatusBar(statusBar);

        retranslateUi(MainWindow);

        tabWidget->setCurrentIndex(0);


        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QCoreApplication::translate("MainWindow", "MainWindow", nullptr));
        tabWidget->setTabText(tabWidget->indexOf(tab_3), QCoreApplication::translate("MainWindow", "\346\225\260\346\215\256\345\210\206\346\236\220", nullptr));
        pushButton_12->setText(QString());
        pushButton_13->setText(QString());
        pushButton_3->setText(QCoreApplication::translate("MainWindow", "\345\274\200\345\247\213\351\200\232\350\256\257", nullptr));
        pushButton_11->setText(QCoreApplication::translate("MainWindow", "\350\207\252\345\212\250\345\267\241\351\200\273", nullptr));
        pushButton_14->setText(QCoreApplication::translate("MainWindow", "\347\242\260\346\222\236\346\243\200\346\265\213", nullptr));
        pushButton_5->setText(QCoreApplication::translate("MainWindow", "\346\270\251\346\271\277\345\272\246\346\243\200\346\265\213", nullptr));
        pushButton_6->setText(QCoreApplication::translate("MainWindow", "\346\260\264\346\265\201\344\276\246\345\257\237", nullptr));
        pushButton_7->setText(QCoreApplication::translate("MainWindow", "\345\205\211\347\205\247\344\276\246\345\257\237", nullptr));
        pushButton_8->setText(QCoreApplication::translate("MainWindow", "\350\266\205\345\243\260\346\263\242\346\216\242\346\265\213", nullptr));
        pushButton->setText(QString());
        pushButton_2->setText(QString());
        pushButton_15->setText(QString());
        checkBox_2->setText(QCoreApplication::translate("MainWindow", "H", nullptr));
        checkBox->setText(QCoreApplication::translate("MainWindow", "T", nullptr));
        checkBox_3->setText(QCoreApplication::translate("MainWindow", "L", nullptr));
        checkBox_4->setText(QCoreApplication::translate("MainWindow", "F", nullptr));
        pushButton_9->setText(QString());
        pushButton_10->setText(QString());
        pushButton_4->setText(QString());
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
