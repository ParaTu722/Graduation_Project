#include "loginwindow.h"
#include "ui_loginwindow.h"
#include "QDebug"
#include "QString"
#include <QMessageBox>
#include <QDesktopWidget>
#include <QSound>



QSound *bk_music = new QSound(":/login_ui.wav");
QSound *click_music = new QSound(":/click.wav");

LoginWindow::LoginWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::LoginWindow)
{
    ui->setupUi(this);

    setFixedSize(this->width(), this->height());

    bk_music->play();
    bk_music->setLoops(-1);

    this->setWindowTitle("机动救援系统");
    this->setWindowIcon(QIcon(":/image/mainwindow_icon.png"));
    this->setWindowFlags(Qt::Dialog|Qt::FramelessWindowHint|Qt::WindowStaysOnTopHint);//无边框化且不可移动

    ui->pushButton->setIcon(QIcon(":/image/click-modified.png"));
    ui->pushButton_2->setIcon(QIcon(":/image/click-modified.png"));

    ui->pushButton_3->setIcon(QIcon(":/image/sendstring-modified.png"));
    ui->pushButton_4->setIcon(QIcon(":/image/sendstring-modified.png"));

}

LoginWindow::~LoginWindow()
{
    delete ui;

}


void LoginWindow::on_pushButton_clicked()
{
    click_music->play();
    QString ac,password;
    ac.clear();
    password.clear();

    ac = ui->lineEdit->text();
    password = ui->lineEdit_2->text();

    qDebug()<<ac;
    qDebug()<<password;

    if(ac != "123" || password != "123")
    {
         QMessageBox::warning(this,tr("Warnning！"),tr("账户密码错误请重新输入！"));
    }
    if(ac == "123" && password == "123")
    {
        bk_music->stop();
        this->close();
        uart *w = new uart();
        w->show();
    }

}

//退出按钮
void LoginWindow::on_pushButton_2_clicked()
{
    click_music->play();
    this->close();

}
