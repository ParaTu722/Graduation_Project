#include "uart.h"
#include "ui_uart.h"
#include "QDebug"
#include "QString"
#include <QMessageBox>
#include <QSound>


QSound *click_music_u = new QSound(":/click.wav");

QString Uart_COM;

uart::uart(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::uart)
{
    ui->setupUi(this);

    setFixedSize(this->width(), this->height());
    this->setWindowTitle("机动救援系统");
    this->setWindowIcon(QIcon(":/image/mainwindow_icon.png"));
    this->setWindowFlags(Qt::Dialog|Qt::FramelessWindowHint|Qt::WindowStaysOnTopHint);//无边框化且不可移动
    ui->pushButton->setIcon(QIcon(":/image/sendmessageC-modified.png"));
    ui->pushButton->setIconSize(QSize(65,65));
}

uart::~uart()
{
    delete ui;
}

void uart::on_pushButton_clicked()
{
    click_music_u->play();
    int len = Uart_COM.length();
    if(len == 4)
    {
        this->close();
        MainWindow *w = new MainWindow();
        w->show();
    }
    else
    {
        QMessageBox::warning(this,tr("Warnning！"),tr("通讯系统未连接，请检查通讯端口！"));
    }

}

void uart::on_comboBox_currentIndexChanged(const QString &arg1)
{
    int index = ui->comboBox->currentIndex();
    if(index == 1)
    {
        Uart_COM.clear();
        Uart_COM = ui->comboBox->currentText();
        qDebug() << Uart_COM;
    }
    else if(index == 2)
    {
        Uart_COM.clear();
        Uart_COM = ui->comboBox->currentText();
        qDebug() << Uart_COM;
    }
    else if(index == 3)
    {
        Uart_COM.clear();
        Uart_COM = ui->comboBox->currentText();
        qDebug() << Uart_COM;
    }
    else if(index == 4)
    {
        Uart_COM.clear();
        Uart_COM = ui->comboBox->currentText();
        qDebug() << Uart_COM;
    }
    else if(index == 5)
    {
        Uart_COM.clear();
        Uart_COM = ui->comboBox->currentText();
        qDebug() << Uart_COM;
    }
    else if(index == 6)
    {
        Uart_COM.clear();
        Uart_COM = ui->comboBox->currentText();
        qDebug() << Uart_COM;
    }
    else if(index == 7)
    {
        Uart_COM.clear();
        Uart_COM = ui->comboBox->currentText();
        qDebug() << Uart_COM;
    }
    else if(index == 8)
    {
        Uart_COM.clear();
        Uart_COM = ui->comboBox->currentText();
        qDebug() << Uart_COM;
    }
    else if(index == 9)
    {
        Uart_COM.clear();
        Uart_COM = ui->comboBox->currentText();
        qDebug() << Uart_COM;
    }
}
