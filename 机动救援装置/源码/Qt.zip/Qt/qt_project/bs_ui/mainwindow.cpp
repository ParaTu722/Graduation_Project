#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "uart.h"
#include <QTime>
#include <QTimer>
#include <QFont>
#include "QString"
#include "string.h"
#include <QMessageBox>
#include <QSound>
//#include "C:\\Users\\ParaT\\AppData\\Local\\Programs\\Python\\Python310\\include\\Python.h"
#include "C:\\Users\\ParaTu\\AppData\\Local\\Programs\\Python\\Python310\\include\\Python.h"
#include <QProcess>
#include <QThread>
#include <windows.h>    //use Sleep
#include <QChart>
#include <QFile>

extern QString Uart_COM;

QSerialPort *serial=  new QSerialPort;


QSound *bk2_music = new QSound(":/bkacground.wav");
QSound *click_music2 = new QSound(":/click.wav");
QSound *click_music3 = new QSound(":/click2.wav");
QSound *warn_music = new QSound(":/warn.wav");
QSound *move_go = new QSound(":/go.wav");
QSound *movie = new QSound(":/movie.wav");
QSound *stop = new QSound(":/stop.wav");
QSound *wifi_request = new QSound(":/wifi_request.wav");

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    qDebug() << Uart_COM;
    ui->setupUi(this);
    bk2_music->play();
    bk2_music->setLoops(-1);
    setFixedSize(806,483);
    //this->resize(900,500); //设置主窗口大小
    this->setWindowTitle("机动救援系统");
    this->setWindowIcon(QIcon(":/image/mainwindow_icon.png"));
    this->setWindowOpacity(1.0);//窗体透明度
    //this->setStyleSheet("#MainWindow{border-image: url(:/image/ui_bj2.png);}");

    //数据分析初始隐藏
    ui->tabWidget->setVisible(0);
    //勾选tabbaraudohide以隐藏表头

    //串口接收框设置
    ui->textEdit->setStyleSheet("background-color:transparent;");//变透明
    ui->textEdit->setReadOnly(true);                             //取消手动输入
    ui->textEdit->setTextColor(QColor("gray"));                 //字体灰色
    ui->textEdit->setHorizontalScrollBarPolicy(Qt::ScrollBarAlwaysOff);//隐藏滚动条
    ui->textEdit->setVerticalScrollBarPolicy(Qt::ScrollBarAlwaysOff);

    //串口发送框设置
    ui->lineEdit->setStyleSheet("background:transparent");


    //串口打开按钮
    ui->pushButton_3->setIcon(QIcon(":/image/openuart-modified.png"));
    //信息快捷发送键设置
    ui->pushButton_11->setIcon(QIcon(":/image/sendmessageC-modified.png"));

    ui->pushButton_5->setIcon(QIcon(":/image/sendmessageC-modified.png"));
    ui->pushButton_5->setIconSize(QSize(35,35));

    ui->pushButton_6->setIcon(QIcon(":/image/sendmessageC-modified.png"));
    ui->pushButton_6->setIconSize(QSize(35,35));

    ui->pushButton_7->setIcon(QIcon(":/image/sendmessageC-modified.png"));
    ui->pushButton_7->setIconSize(QSize(35,35));

    ui->pushButton_8->setIcon(QIcon(":/image/sendmessageC-modified.png"));
    ui->pushButton_8->setIconSize(QSize(35,35));

    ui->pushButton_14->setIcon(QIcon(":/image/sendmessageC-modified.png"));
    ui->pushButton_14->setIconSize(QSize(35,35));

    //网络状态初始化
    ui->pushButton_12->setIcon(QIcon(":/image/wifi_off.png"));
    ui->pushButton_12->setIconSize(QSize(30,30));
    //串口状态初始化
    ui->pushButton_13->setIcon(QIcon(":/image/uart_off.png"));
    ui->pushButton_13->setIconSize(QSize(30,30));

    //ui->pushButton_15->setEnabled(false);

    /*通讯串口*/
    //设置串口名
    serial->setPortName(Uart_COM); //"COM4"
    //设置波特率
    serial->setBaudRate(115200);
    //设置数据位数
    serial->setDataBits(QSerialPort::Data8);
     //设置奇偶校验
    serial->setParity(QSerialPort::NoParity);
    //设置停止位
    serial->setStopBits(QSerialPort::OneStop);
    //设置流控制
    serial->setFlowControl(QSerialPort::NoFlowControl);
    //时钟
    QTimer *timer = new QTimer(this);
    timer->start(1000);
    connect(timer,SIGNAL(timeout()),this,SLOT(timerUpdata()));


    //x轴
    axisX = new QValueAxis();
    axisX->setRange(0, 20);//范围
    axisX->setLabelFormat("%d");
    axisX->setGridLineVisible(false);//网格 存在
    //axisX->setTitleText("探测次数");//标题
    axisX->setTickCount(11);
    axisX->setLabelsColor(QColor(10,255,255));
    axisX->setTitleFont(QFont("微软雅黑",15,50));
    axisX->setTitleBrush(QBrush(QColor(10,255,255)));

    //y轴
    axisY = new QValueAxis();
    axisY->setRange(0, 100);
    axisY->setLabelFormat("%d");
    axisY->setGridLineVisible(false);
    //axisY->setTitleText("探测变化量");
    axisY->setTitleFont(QFont("微软雅黑",15,50));
    axisY->setTitleBrush(QBrush(QColor(10,255,255)));
    axisY->setTickCount(5);
    axisY->setLabelsColor(QColor(10,255,255));

    //绑定到图表中
    chart = new QChart();
    chart->setTitleFont(QFont("微软雅黑",15,75));//设置标题字体
    chart->setTitle("航 行 分 析");
    chart->setTitleBrush(QBrush(QColor(15,255,255)));
    chart->setBackgroundVisible(false);

    //曲线创建
    series_humidity = new QSplineSeries();//实例化一个QLineSeries对象
    series_temperature = new QSplineSeries();//实例化一个QLineSeries
    series_flow = new QSplineSeries();//实例化一个QLineSeries对象
    series_light = new QSplineSeries();//实例化一个QLineSeries对象

    //曲线命名
    series_humidity->setName("湿度[%]");
    series_temperature->setName("温度(℃)");
    series_flow->setName("水流【%】");
    series_light->setName("光照(%)");

    //数据标注,湿度
    series_humidity->setColor(QColor(255,0,0));
    //曲线上点数据设置
    QFont font = series_humidity->pointLabelsFont();//用font设置pointLabels默认字体格式
    font.setBold(true);// 加粗
    font.setPointSize(8);// 设置字体大小

    series_humidity->setPointLabelsFormat("[@yPoint%]");//点数据显示样式
    series_humidity->setPointLabelsColor(QColor(255,255,255));//点数据显示颜色
    series_humidity->setPointLabelsFont(font);// 更新pointLabels字体参数
    series_humidity->setPointsVisible(true);//允许绘点
    series_humidity->setPointLabelsClipping(false);//获取和设置是否对点标签超出绘图区域边缘的部分进行裁剪

    //数据标注,温度
    series_temperature->setColor(QColor(0,255,0));
    QFont font1 = series_temperature->pointLabelsFont();
    font1.setBold(true);
    font1.setPointSize(8);
    series_temperature->setPointLabelsFormat("@yPoint℃");//数据标注
    series_temperature->setPointLabelsFont(font1);//标签点字体
    series_temperature->setPointLabelsColor(QColor(255,255,255));//标签点颜色
    series_temperature->setPointsVisible(true);//允许绘点
    series_temperature->setPointLabelsClipping(false);//获取和设置是否对点标签超出绘图区域边缘的部分进行裁剪

    //数据标注,水流
    series_flow->setColor(QColor(248,154,194));
    QFont font2 = series_flow->pointLabelsFont();
    font2.setBold(true);
    font2.setPointSize(8);
    series_flow->setPointLabelsFormat("【@yPoint%】");//数据标注
    series_flow->setPointLabelsFont(font2);
    series_flow->setPointLabelsColor(QColor(255,255,255));
    series_flow->setPointsVisible(true);
    series_flow->setPointLabelsClipping(false);

    //数据标注,光照
    series_light->setColor(QColor(255,128,0));
    QFont font3 = series_light->pointLabelsFont();
    font3.setBold(true);
    font3.setPointSize(8);
    series_light->setPointLabelsFormat("(@yPoint%)");//数据标注
    series_light->setPointLabelsFont(font3);
    series_light->setPointLabelsColor(QColor(255,255,255));
    series_light->setPointsVisible(true);
    series_light->setPointLabelsClipping(false);

    //曲线绑定到视图
    chart->addSeries(series_humidity);
    chart->setAxisX(axisX,series_humidity);
    chart->setAxisY(axisY,series_humidity);

    chart->addSeries(series_temperature);
    chart->setAxisX(axisX,series_temperature);
    chart->setAxisY(axisY,series_temperature);

    chart->addSeries(series_flow);
    chart->setAxisX(axisX,series_flow);
    chart->setAxisY(axisY,series_flow);

    chart->addSeries(series_light);
    chart->setAxisX(axisX,series_light);
    chart->setAxisY(axisY,series_light);

    chart->legend()->setAlignment(Qt::AlignBottom);//底部对齐
    chart->legend()->setLabelColor(QColor(255,255,255));//设置标签颜色
    chart->legend()->setVisible(true);


    chartView = new QChartView(chart,this);
    chartView->setRenderHint(QPainter::Antialiasing);//防止图像走样（抗锯齿）
    chartView->setStyleSheet("background: transparent");

    layout = new QHBoxLayout();
    layout->addWidget(chartView);
    ui->widget->setLayout(layout);
    QObject::connect(serial,&QSerialPort::readyRead,this,&MainWindow::Read_Data);

}

MainWindow::~MainWindow()
{
    delete ui;
}

QString str;

//时钟
void MainWindow::timerUpdata()
{
    QDateTime time = QDateTime::currentDateTime();
    QString str1 = time.toString("yyyy-MM-dd hh:mm:ss");
    ui->lcdNumber->display(str1);
    if(!str.isEmpty())
    {
        ui->textEdit->append(str);
        str.clear();
    }
}

int flag=0;
//串口打开
void MainWindow::on_pushButton_3_clicked()
{
    click_music2->play();
    flag++;
    if(flag==1)
    {
        serial->open(QIODevice::ReadWrite);
        if(serial->isOpen())
        {
           ui->pushButton_13->setIcon(QIcon(":/image/uart_on.png"));
           ui->pushButton_3->setText("终止通讯");
           //qDebug()<<"COM3 is open!";
        }
        else
        {
           ui->pushButton_13->setIcon(QIcon(":/image/uart_off.png"));
           ui->pushButton_3->setText("开始通讯");
           qDebug()<<"open fail!";
           QMessageBox::warning(this,tr("Warnning！"),tr("双端连接有误，请重试！"));
           flag=0;
        }
    }
    if(flag==2 && serial->isOpen())
    {
        ui->pushButton_13->setIcon(QIcon(":/image/uart_off.png"));
        flag=0;
        ui->pushButton_3->setText("开始通讯");
        serial->clear();
        serial->close();
        qDebug()<<"close successful!";
    }
}

//发送数据
void MainWindow::on_pushButton_clicked()
{
    click_music3->play();
    serial->write(ui->lineEdit->text().toLatin1());
    //ui->textEdit->append(ui->lineEdit->text());
}

int f=0;
double hd[21];
double td[21];
double wd[21];
double ld[21];
//读数据
void MainWindow::Read_Data()
{
    QString curve_data;//all获取的字符串
    QStringList data_list;//存贮字符串中的数字
    //正则读取字符串中的数字
    QRegExp rx("-?(([1-9]\\d*\\.\\d*)|(0\\.\\d*[1-9]\\d*)|([1-9]\\d*))");
    int p = 0;
    QByteArray buf;
    buf = serial->readAll();//串口读到的数据
    if(!buf.isEmpty())
    {
        str = tr(buf);
        //显示在中控上
        //str = ui->textEdit->toPlainText();
        qDebug()<<buf;
        //qDebug()<<len_buf;

        //如果符合绘图数据要求
        int len_buf = buf.size();//串口读到的数据的长度
        if(f>=21)
        {
            f=0;
            memset(hd,0,sizeof(hd));
            memset(td,0,sizeof(td));
            memset(wd,0,sizeof(wd));
            memset(ld,0,sizeof(ld));
        }
        if((len_buf==31 || len_buf==30) && (f <21) && tr(buf).contains("H:",Qt::CaseSensitive)&& tr(buf).contains("T:",Qt::CaseSensitive)&& tr(buf).contains("F:",Qt::CaseSensitive))
        {
            //data_list.clear();
            curve_data = tr(buf);
            //qDebug()<<curve_data;
            while ((p = rx.indexIn(curve_data, p)) != -1)
            {
                data_list.append(rx.cap(1));
                p += rx.matchedLength(); // 上一个匹配的字符串的长度
            }
            qDebug()<<f;
            hd[f] = data_list[0].toDouble();
            td[f] = data_list[1].toDouble();
            wd[f] = data_list[2].toDouble();
            ld[f] = data_list[3].toDouble();
            f++;
        }
    }
    buf.clear();
    data_list.clear();
}


//清空接收区
void MainWindow::on_pushButton_2_clicked()
{
    click_music3->play();
    ui->textEdit->clear();
    ui->lineEdit->clear();
    str.clear();
}

//温湿度获取
void MainWindow::on_pushButton_5_clicked()
{
    click_music3->play();
    if(serial->isOpen())
    {
        serial->write("d-t");
    }
    else
    {
         QMessageBox::warning(this,tr("Warnning！"),tr("通讯系统未开启，请检查！"));
    }
}

//雨滴
void MainWindow::on_pushButton_6_clicked()
{
    click_music3->play();
    if(serial->isOpen())
    {
        serial->write("rain");
    }
    else
    {
         QMessageBox::warning(this,tr("Warnning！"),tr("通讯系统未开启，请检查！"));
    }
}
//光敏
void MainWindow::on_pushButton_7_clicked()
{
    click_music3->play();
    if(serial->isOpen())
    {
        serial->write("light");
    }
    else
    {
         QMessageBox::warning(this,tr("Warnning！"),tr("通讯系统未开启，请检查！"));
    }
}
//超声波
void MainWindow::on_pushButton_8_clicked()
{
    click_music3->play();
    if(serial->isOpen())
    {
        serial->write("SonicDetection");
    }
    else
    {
         QMessageBox::warning(this,tr("Warnning！"),tr("通讯系统未开启，请检查！"));
    }
}

//碰撞检查
void MainWindow::on_pushButton_14_clicked()
{
    click_music3->play();
    if(serial->isOpen())
    {
        serial->write("collide");
    }
    else
    {
         QMessageBox::warning(this,tr("Warnning！"),tr("通讯系统未开启，请检查！"));
    }
}


//舵机前进
int run_flag=0;
void MainWindow::on_pushButton_10_clicked()
{
    run_flag++;
    if(serial->isOpen())
    {
        if(run_flag==1)
        {
            move_go->play();
            ui->textEdit->clear();
            ui->textEdit->append("设备正在前进\r\n");
            serial->write("gogo");
            ui->pushButton_10->setStyleSheet("border-image: url(:/image/go.png);");
        }
        if(run_flag==2)
        {
            stop->play();
            ui->textEdit->clear();
            serial->write("stop");
            ui->textEdit->append("设备停止前进\r\n");
            ui->pushButton_10->setStyleSheet("border-image: url(:/image/stop.png);");
            run_flag=0;
        }
    }
    else
    {
        click_music2->play();
        ui->textEdit->clear();
        ui->textEdit->append("设备启动异常!!!\r\n");
        run_flag=0;
    }

}



//获取所有信息
int all_flag=0;
QTimer *timer_s = new QTimer();
//开始获取
void MainWindow::automatic_send()
{
    serial->clear();
    serial->write("all");
}

void MainWindow::on_pushButton_11_clicked()
{
    click_music3->play();
    all_flag++;
    timer_s->setInterval(1500);
    if(all_flag==1 && serial->isOpen())
    {
        timer_s->start();
        connect(timer_s,SIGNAL(timeout()),this,SLOT(automatic_send()));
        ui->pushButton_11->setIcon(QIcon(":/image/allsend.png"));
        ui->pushButton_11->setText("结束巡逻");
    }
    else if(all_flag==2 && serial->isOpen())
    {
        timer_s->stop();
        ui->pushButton_11->setText("自动巡逻");
        ui->pushButton_11->setIcon(QIcon(":/image/sendmessageC-modified.png"));
        all_flag=0;
    }
    else
    {
         QMessageBox::warning(this,tr("Warnning！"),tr("通讯系统未开启，请检查！"));
         all_flag=0;
    }

}

//sos按钮
int sos_flag=0;
void MainWindow::on_pushButton_4_clicked()
{
    warn_music->play();
    warn_music->setLoops(-1);
    sos_flag++;
    if(sos_flag==1)
    {
        sos_flag=0;
        QMessageBox MBox;
        MBox.setWindowTitle("SOS紧急发送确认");
        MBox.setText("设备发现紧急情况，即将向用户发送警告信息！");
        MBox.setIconPixmap(QPixmap(":/image/sos.jpg"));
        QPushButton *agreeBut1 = MBox.addButton("我同意", QMessageBox::AcceptRole);
        QPushButton *agreeBut2 = MBox.addButton("我再想想", QMessageBox::AcceptRole);
        MBox.exec();
        if (MBox.clickedButton() == (QAbstractButton*)agreeBut1)
        {
            ui->textEdit->clear();
            ui->textEdit->append("设备已向用户发送警报！！！\r\n");
            //在 Qt Creator 的输出窗口中输出指定字符串
            qDebug() << "用户点击了同意按钮";

            Py_Initialize();
            PyRun_SimpleString("import sys");
            PyRun_SimpleString("sys.argv = ['python.py']");
            PyRun_SimpleString("sys.path.append('./')");
            PyObject* pModule = PyImport_ImportModule("接收短信");
            if (!pModule)
             {
                 qDebug()<<"Cant open python file!\n";
             }
            qDebug()<<"已发送";
            //结束，释放python
            Py_Finalize();

            warn_music->stop();
        }
        if (MBox.clickedButton() == (QAbstractButton*)agreeBut2)
        {
            //在 Qt Creator 的输出窗口中输出指定字符串
            ui->textEdit->append("已关闭警报发送！！！\r\n");
            qDebug() << "用户点击了我再想想按钮";
            warn_music->stop();
        }
    }
}


//摄像头？如何解决重复启动问题
int camer_click_flag = 0;
void MainWindow::on_pushButton_9_clicked()
{
    /*
    movie->play();
    serial->write("movie");
    QString cmd = ":/picture.exe";
    QProcess *movie = new QProcess;
    ui->textEdit->append("画面启动中请稍后......\r\n");
    qDebug() << "画面启动中请稍后......";
    movie->start(cmd);
    //等待2s程序启动完成，成功后返回为真
    movie->waitForFinished(2000);
    */
    camer_click_flag++;
    if(camer_click_flag==1)
    {
        movie->play();
        serial->write("movie");
        ui->textEdit->append("画面启动中请稍后......\r\n");
        qDebug() << "画面启动中请稍后......";
        QString EXEName_src = ":/picture.exe";
        QString EXEName_Dst = "picture.exe";
        QFile EXEFile_src(EXEName_src);
        QFile EXEFile_Dst(EXEName_Dst);

        if (EXEFile_Dst.open(QIODevice::WriteOnly))
        {
            if (EXEFile_src.open(QIODevice::ReadOnly))
            {
                QByteArray tmp = EXEFile_src.readAll();
                EXEFile_Dst.write(tmp);
            }
        }
        EXEFile_Dst.close();
        EXEFile_src.close();
        QString CMD = EXEName_Dst;

        //执行CMD命令
        /*************非阻塞式调用***********/
        QProcess process(this);
        process.startDetached(CMD);
        QFile::remove(EXEName_Dst); //删掉exe文件
    }
    else
    {
        ui->textEdit->append("已启动或启动异常！\r\n");
        camer_click_flag=0;
    }

}

//网络状态点击
void MainWindow::on_pushButton_12_clicked()
{
    QString network_cmd = "ping www.baidu.com -n 1 -w 500"; //-n：可以指定发送多少数据包；-w：等待回复的超时时间（毫秒）
    QString result;
    network_test = new QProcess();    //不要加this
    network_test->start(network_cmd);   //调用ping 指令
    network_test->waitForFinished();    //等待指令执行完毕
    result = network_test->readAll();   //获取指令执行结果
    if(result.contains(QString("TTL=")))   //若包含TTL=字符串则认为网络在线
    {
        click_music2->play();
        ui->textEdit->append("设备网络连接成功！\r\n");
        ui->pushButton_12->setIcon(QIcon(":/image/wifi_on.png"));
        ui->pushButton->setEnabled(true);
    }
    else
    {
        ui->textEdit->append("设备网络连接失败！\r\n");
        ui->pushButton_12->setIcon(QIcon(":/image/wifi_off.png"));
        ui->pushButton->setDisabled(true);
    }
    //Sleep(1);
}


//读取数据并绘制曲线图
void MainWindow::draw_xy()
{
    series_humidity->clear();
    series_temperature->clear();
    series_flow->clear();
    series_light->clear();
    //数据标注,湿度
    /*
    series_humidity->append(0,33.3);
    series_temperature->append(0,33.3);
    series_flow->append(2,35.3);
    series_light->append(9,80.3);

    series_humidity->append(f,hd[f]);
    series_temperature->append(f,td[f]);
    series_flow->append(f,wd[f]);
    series_light->append(f,ld[f]);
    */
    int i=0;
    while (!(ld[i]==td[i]==wd[i]==hd[i]))
    {

       series_humidity->append(i,hd[i]);
       series_temperature->append(i,td[i]);
       series_flow->append(i,wd[i]);
       series_light->append(i,ld[i]);
       i++;
    }


}

//数据分析按钮
int data_flag=0;
QTimer *timer_dd = new QTimer();
void MainWindow::on_pushButton_15_clicked()
{

    timer_dd->setInterval(1500);
    click_music3->play();
    data_flag++;
    if(data_flag==1)
    {
        ui->textEdit->append("开始进行数据分析，每隔一秒更新一次。");
        ui->tabWidget->setVisible(1);
        ui->tabWidget->setStyleSheet("QTabWidget:pane {border-top:0px solid #e8f3f9;background:  transparent; }");
        ui->pushButton_15->setStyleSheet("border-image: url(:/image/data_analyse_black.png);");
        setFixedSize(1452,483);
        this->setStyleSheet("#MainWindow{border-image: url(:/image/data_ui_bj.png);}");
        timer_dd->start();
        connect(timer_dd,SIGNAL(timeout()),this,SLOT(draw_xy()));

    }
    else if(data_flag==2)
    {
        ui->textEdit->append("数据分析已关闭。");
        timer_dd->stop();
        series_humidity->clear();
        series_temperature->clear();
        series_flow->clear();
        series_light->clear();
        ui->tabWidget->setVisible(0);
        ui->pushButton_15->setStyleSheet("border-image: url(:/image/data_analyse.png);");
        data_flag=0;
        setFixedSize(806,483);
        this->setStyleSheet("#MainWindow{border-image: url(:/image/ui_bj2.png);}");
    }
}

//依据所需选择，不同曲线的数据显示
void MainWindow::on_checkBox_stateChanged(int arg1)
{
    click_music3->play();
    bool status =ui->checkBox->isChecked();
    if(status == true)
    {

        series_temperature->setPointLabelsVisible(true);//标签点可见
        qDebug()<<"表示被选中T";
    }
    else if(status == false)
    {
        series_temperature->setPointLabelsVisible(false);//标签点可见
        qDebug()<<"表示未被选中T";
    }
}

void MainWindow::on_checkBox_2_stateChanged(int arg1)
{
    click_music3->play();
    bool status =ui->checkBox_2->isChecked();
    if(status == true)
    {
        series_humidity->setPointLabelsVisible(true);//点数据显示
        qDebug()<<"表示被选中H";
    }
    else if(status == false)
    {
        series_humidity->setPointLabelsVisible(false);//点数据隐藏
        qDebug()<<"表示未被选中H";
    }
}

void MainWindow::on_checkBox_3_stateChanged(int arg1)
{
    click_music3->play();
    bool status =ui->checkBox_3->isChecked();
    if(status == true)
    {
        series_flow->setPointLabelsVisible(true);
        qDebug()<<"表示被选中F";
    }
    else if(status == false)
    {
        series_flow->setPointLabelsVisible(false);
        qDebug()<<"表示未被选中F";
    }
}

void MainWindow::on_checkBox_4_stateChanged(int arg1)
{
    click_music3->play();
    bool status =ui->checkBox_4->isChecked();
    if(status == true)
    {
        series_light->setPointLabelsVisible(true);
        qDebug()<<"表示被选中L";
    }
    else if(status == false)
    {
        series_light->setPointLabelsVisible(false);
        qDebug()<<"表示未被选中L";
    }
}
