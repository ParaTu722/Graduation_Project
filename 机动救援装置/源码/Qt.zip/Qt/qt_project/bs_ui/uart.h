#ifndef UART_H
#define UART_H

#include <QMainWindow>
#include "mainwindow.h"

namespace Ui {
class uart;
}

class uart : public QMainWindow
{
    Q_OBJECT

public:
    explicit uart(QWidget *parent = nullptr);
    ~uart();

private slots:
    void on_pushButton_clicked();

    void on_comboBox_currentIndexChanged(const QString &arg1);

private:
    Ui::uart *ui;
};

#endif // UART_H
