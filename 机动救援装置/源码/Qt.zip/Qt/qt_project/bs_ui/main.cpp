#include "mainwindow.h"
#include "loginwindow.h"
#include "uart.h"
#include <QApplication>
#include <QDialog>
#include <QDesktopWidget>


int main(int argc, char *argv[])
{
    QApplication a(argc, argv);

    MainWindow w;
    LoginWindow l;
    uart com;


    com.show();
    //l.show();
    //w.show();
    return a.exec();

}
