#ifndef __LIGHTSENSOR_H_
#define __LIGHTSENSOR_H_


//光敏的DO连接 PA0口
void LIGHTSENSOR_Init(void);
uint8_t LIGHTSENSOR_Get(void);
    
#endif
