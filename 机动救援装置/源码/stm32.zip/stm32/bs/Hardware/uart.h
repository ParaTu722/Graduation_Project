#ifndef __UART_H_
#define __UART_H_
#include "stm32f10x.h"
#include <stdio.h>

extern char USART_ReceiveString[50];
extern int Receive_Flag;

void uart_init(void);
void Usart_SendByte( USART_TypeDef * pUSARTx, uint8_t ch);
void Usart_SendString( USART_TypeDef * pUSARTx, char *str);
unsigned char UART1GetByte(unsigned char* GetData);

#endif
