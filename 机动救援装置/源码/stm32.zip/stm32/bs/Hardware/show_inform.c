#include "stm32f10x.h"  
#include "Delay.h"
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include "Led_Core.h"
#include "Led_Bottom.h"
#include "Buzzer.h"
#include "OLED.h"
#include "ad.h"
#include "DHT11.h"
#include "HC_SR04.h"
#include "keyexit.h"
#include "uart.h"
#include "pwm.h"
#include "infrared.h"



uint16_t ADvalue1 = 0;//雨滴值
uint16_t ADvalue2 = 0;//光敏值
int16_t encoder_function_Num = 0;		//旋转编码器转动数字以此进入对于功能

extern uint8_t dat[5];//温湿度值
extern uint8_t flag;


//int 转 字符串
char* Int2String(int num,char *str)//10进制 
{
	int i = 0;//指示填充str 
	if(num<0)//如果num为负数，将num变正 
	{
		num = -num;
		str[i++] = '-';
	} 
	//转换 
	do
	{
		str[i++] = num%10+48;//取num最低位 字符0~9的ASCII码是48~57；简单来说数字0+48=48，ASCII码对应字符'0' 
		num /= 10;//去掉最低位	
	}while(num);//num不为0继续循环
	
	str[i] = '\0';
	
	//确定开始调整的位置 
	int j = 0;
	if(str[0]=='-')//如果有负号，负号不用调整 
	{
		j = 1;//从第二位开始调整 
		++i;//由于有负号，所以交换的对称轴也要后移1位 
	}
	//对称交换 
	for(;j<i/2;j++)
	{
		//对称交换两端的值 其实就是省下中间变量交换a+b的值：a=a+b;b=a-b;a=a-b; 
		str[j] = str[j] + str[i-1-j];
		str[i-1-j] = str[j] - str[i-1-j];
		str[j] = str[j] - str[i-1-j];
	} 
	
	return str;//返回转换后的值 
}


//系统初始化
void init(void)
{
	LedCore_Init();
	LedBottom_Init();
	Buzzer_Init();      
	//KEY_Init();
	OLED_Init();
	AD_Init();
	HC_SR04_init();
	PWM_Init();
	keyexit_init();
	uart_init();
	Infrared_Init();
}


//蜂鸣器警报
void bwarm1()
{
		Buzzer_ON();
		Delay_ms(50);
		Buzzer_OFF();
}

/***********************************************************************/
/***********************************************************************/
/***************************温湿度***显示以及警报***********************/
/***********************************************************************/
/***********************************************************************/

//湿度警报
void warming1()
{
	while(1)
	{	
	OLED_ShowString(1,1,"--------------- ");
	OLED_ShowString(2,1,"|H is too high| ");
	OLED_ShowString(3,1,"| turn it down| ");
	OLED_ShowString(4,1,"--------------- ");
	
	Led02Bottom_Turn();
	bwarm1();
	DHT_Read();
	
	if(dat[0]<70)
		{
			OLED_Clear();
			break;
		}
	}	
}

//温度警报
void warming2()
{
	while(1)
	{	
		OLED_ShowString(1,1,"--------------- ");
		OLED_ShowString(2,1,"|T is too high| ");
		OLED_ShowString(3,1,"| turn it down| ");
		OLED_ShowString(4,1,"--------------- ");
		
		Led02Bottom_Turn();
		bwarm1();
		DHT_Read();
		
		if(dat[2]<30)
		{
			OLED_Clear();
			break;
		}
	}
}

//温湿度获取，显示
void TorH(void)
{
	DHT_Read();
	Delay_ms(30);
	OLED_ShowString(1,1,"T:");
	OLED_ShowNum(1,3,dat[2],2);
	OLED_ShowString(1,5,"^C ");
	
	OLED_ShowString(1,8,"H:");
	OLED_ShowNum(1,10,dat[0],2);
	OLED_ShowString(1,12,"%    ");
	
	OLED_ShowString(2,1,"----Everything  ");
	OLED_ShowString(3,1,"------Works     ");
	OLED_ShowString(4,1,"--------Fine    ");	 
	
	if(dat[0]>70)			
	{
		printf("!!!High Humidity Warning!!!\r\n");
		printf("!!!High Humidity Warning!!!\r\n");
		warming1();
	}
	if(dat[2]>30)			
	{
		printf("!!!High Temperature Warning!!!\r\n");
		printf("!!!High Temperature Warning!!!\r\n");
		warming2();
	}
}

/***********************************************************************/
/***********************************************************************/
/***************************水流强度***显示以及警报*********************/
/***********************************************************************/
/***********************************************************************/


//水流警报
void rain_warm1()
{
	while(1)
	{	
		ADvalue1 = Get_ADValue(ADC_Channel_7);
		Delay_ms(50);
		int rval = 99-((float)ADvalue1*3.3/4096)*2*99.0/5.0;
		OLED_ShowString(1,1,"--------------- ");
		OLED_ShowString(2,1,"   Water Large  ");
		OLED_ShowString(3,1,"   Water Large  ");
		OLED_ShowString(4,1,"--------------- ");
		bwarm1();
		Led02Bottom_Turn();
		if(rval < 70)
		{
			break;
		}
	}
}

//雨滴值获取，显示
void rain()
{
	int rval;
	OLED_ShowString(1,1,"Flow intensity  ");
	ADvalue1 = Get_ADValue(ADC_Channel_7);
	rval = 99-((float)ADvalue1*3.3/4096)*2*99.0/5.0;
	OLED_ShowString(2,1,"  ");
	OLED_ShowNum(2,3,rval,2);
	OLED_ShowString(2,5,"%           ");
	OLED_ShowString(3,1,"                ");
	OLED_ShowString(4,1,"                ");
	if(rval >= 70)
	{
		printf("!!!Flow intensity Warning!!!\r\n");
		printf("!!!     Water Large      !!!\r\n");
		rain_warm1();
	}
	Delay_ms(50);
}


/***********************************************************************/
/***********************************************************************/
/***************************光照强度***显示以及警报*********************/
/***********************************************************************/
/***********************************************************************/


//环境太暗了
void light_warm1()
{
	while(1)
	{	
		ADvalue2 = Get_ADValue(ADC_Channel_3);
		Delay_ms(50);
		int light_intensity = 99-((float)ADvalue2*3.3/4096)*2*99.0/5.0;
		OLED_ShowString(1,1,"--------------- ");
		OLED_ShowString(2,1," It^s too dark  ");
		OLED_ShowString(3,1," It^s too dark  ");
		OLED_ShowString(4,1,"--------------- ");
		bwarm1();
		Led02Bottom_Turn();
		if(light_intensity > 20)
		{
			OLED_Clear();
			break;
		}
	}
}
//环境太亮了
void light_warm2()
{
	while(1)
	{	
		ADvalue2 = Get_ADValue(ADC_Channel_3);
		Delay_ms(50);
		int light_intensity = 99-((float)ADvalue2*3.3/4096)*2*99.0/5.0;
		OLED_ShowString(1,1,"--------------- ");
		OLED_ShowString(2,1," It^s so bright ");
		OLED_ShowString(3,1," It^s so bright ");
		OLED_ShowString(4,1,"--------------- ");
		bwarm1();
		Led02Bottom_Turn();
		if(light_intensity < 80)
		{
			OLED_Clear();
			break;
		}
	}
}
//光敏获取，显示
void light()
{
	ADvalue2 = Get_ADValue(ADC_Channel_3);
	Delay_ms(100);
	OLED_ShowString(1,1,"Light intensity ");
	OLED_ShowString(2,1,"  ");
	int light_intensity = 99-((float)ADvalue2*3.3/4096)*2*99.0/5.0;
	OLED_ShowNum(2,3,light_intensity,2);
	OLED_ShowString(2,5,"%           ");
	OLED_ShowString(3,1,"                ");
	OLED_ShowString(4,1,"                ");
	if(light_intensity < 20)
	{
		printf("!!!Light intensity Warning!!!\r\n");
		printf("!!!        Too Dark       !!!\r\n");
		light_warm1();
	}
	if(light_intensity > 80)
	{
		printf("!!!Light intensity Warning!!!\r\n");
		printf("!!!       Too Bright      !!!\r\n");
		light_warm2();
	}
}


//障碍检测
void barricade_detection()
{
	if(check_a0 == 1)
	{
		//无障碍
		printf("Unobstructed Ahead\r\n");
	}
	else
	{
		//有障碍
		printf("Encounter Roadblocks!\r\n");
	}
}

//读取所有数据
void read_all()
{
	DHT_Read();
	int m1 = dat[0];//H,小数点前
	int m2 = dat[1];//H,小数点后
	int m3 = dat[2];
	int m4 = dat[3];

	int rval;
	ADvalue1 = Get_ADValue(ADC_Channel_7);
	rval = 99-((float)ADvalue1*3.3/4096)*2*99.0/5.0;

	ADvalue2 = Get_ADValue(ADC_Channel_3);
	Delay_ms(50);
	int light_intensity = 99-((float)ADvalue2*3.3/4096)*2*99.0/5.0;
	
	printf("H:%d.%d%% T:%d.%d^C F:%d%% L:%d%%\r\n",m1,m2,m3,m4,rval,light_intensity);
}


//正常报告显示
void show()
{
	OLED_ShowString(1,1,"Normal Operation");
	OLED_ShowString(2,1,"     Command    ");
	OLED_ShowString(3,2,"   Receiving    ");
	OLED_ShowString(4,1,"      ...       ");
}

