#ifndef __AD_H_
#define __AD_H_

void AD_Init(void);
uint16_t Get_ADValue(uint8_t ADC_Channel);

#endif
