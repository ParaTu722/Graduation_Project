#ifndef __PWM_H_
#define __PWM_H_

void PWM_Init(void);
void PWM_Setcompare1(uint16_t Compare1);
#endif
