#ifndef __SHOW_INFORM_H_
#define __SHOW_INFORM_H_

void init(void);
void bwarm1(void);
void warming1(void);
void warming2(void);
void rain(void);
void light(void);
void TorH(void);
void show(void);
char* Int2String(int num,char *str);
void encoder_show(void);
void barricade_detection(void);
void read_all(void);

#endif
