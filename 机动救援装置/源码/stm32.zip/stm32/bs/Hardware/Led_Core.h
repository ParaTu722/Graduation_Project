#ifndef __LED_CORE_H_
#define __LED_CORE_H_

void LedCore_Init(void);
void LedCore_ON(void);
void LedCore_OFF(void);
void LedCore_Blink(int x);

#endif
