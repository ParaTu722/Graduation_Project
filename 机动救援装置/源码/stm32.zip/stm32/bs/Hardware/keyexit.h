#ifndef __KEYEXIT_H_
#define __KEYEXIT_H_

void keyexit_init(void);
int16_t key_Get(void);

#endif
