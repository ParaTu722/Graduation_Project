#ifndef __SERVER_H_
#define __SERVER_H_


void SERVER_Init(void);
void SERVER_SetAngle(float Angle);
    
#endif
