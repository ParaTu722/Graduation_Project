# ifndef __TIMER_H_
# define __TIMER_H_

void TIMER_Init(void);
uint16_t  TIMER_GetCount(void);

#endif
