#include "stm32f10x.h"
#include "Delay.h"

#include <string.h>
#include <stdio.h>
#include "Led_Core.h"
#include "Led_Bottom.h"
#include "Buzzer.h"
#include "OLED.h"
#include "ad.h"
#include "DHT11.h"
#include "HC_SR04.h"
#include "show_inform.h"
#include "uart.h"
#include "keyexit.h"
#include "pwm.h"
#include "infrared.h"


/*

引脚说明：
--------------------------------------------
	蜂鸣器：				PA4
	底板LED：				PA1,PA2,PA3
	核心板LED：			PC13
	中断按键：			PB4,PB5,5使用，4未使用
	中断按键优先级：PB5 > PB4
	OLED显示器：		PB8,PB9
	DHT11:					PA11
	HC_SR04:				PA12(Echo),PB3(Trig),TIM2
	PWM舵机:				PA6,TIM3
	ADC：						ADC1
	雨滴：					PA7，通道7
	光敏：					PA3，通道3
	串口						PA9,PA10
	红外线					PB0
--------------------------------------------

*/


uint16_t  Cnt;			//系统开启百分百显示
uint8_t s_temp=0;				//舵机运行标志	1运行 0停止
uint8_t s_flag = 0;		//超声波运行标志	1运行 0停止

extern int16_t encoder_function_Num;
extern uint8_t dat[5];//温湿度值
extern uint16_t ADvalue1;//雨滴值
extern uint16_t ADvalue2;//光敏值
extern int Receive_sum ;


//系统初始化界面
void show_init()
{
	OLED_ShowString(1,1,"---------------");
	OLED_ShowString(2,1,"|    welcome  |");
	OLED_ShowString(3,1,"|    system   |");
	OLED_ShowString(4,1,"--   ");
	OLED_ShowString(4,10,"    -- ");
	for(Cnt=0;Cnt<=100;Cnt++)
	{
		Delay_ms(20);
		OLED_ShowNum(4,6,Cnt,3);
		OLED_ShowString(4,9,"%");
	}
}


//超声波1：此功能由串口消息触发读值，并发回串口 
void sr04_uart()
{
	int j=0;
	float length;
	
	if(s_flag == 1)
	{
		OLED_Clear();
		for(j=0 ; j<=15 ; j++)
		{
			OLED_ShowString(1,1,"SonicDetection");
			length=Hcsr04GetLength();
			Delay_ms(50);
			length = length/2;
			printf("SonicDetection:%3f\r\n",length);
		}
		j=0;
		Delay_ms(20);
	}
	s_flag=0;
}

//超声波2：此功能由按键触发读值，并lcd显示
void sr04_lcd()
{
	int j=0;
	float length;
	char strff[10];
	if(s_flag == 1)
	{
		OLED_Clear();
		for(j=0 ; j<=15 ; j++)
		{
			OLED_ShowString(1,1,"SonicDetection");
			length=Hcsr04GetLength();
			Delay_ms(50);
			length = length/2;
			sprintf(strff,"%.3f",length);
			OLED_ShowString(2,3,strff);
		}
		j=0;
		Delay_ms(20);
	}
	s_flag=0;
}



int main(void)
{
	//1.系统配置初始化
	init();	
	//2.界面初始化
	show_init();	
	//3.串口发送启动stm32407，以LED1作启动
	Usart_SendString(USART1,"Equipment Start Now\r\n");
	Led01Bottom_ON();
	//4.进入系统功能
	char rx_buf[50];//消息存储区
	while(1)
	{
		//接收数据标志位等于1（接收完毕，停止接收）
		if(Receive_Flag == 1)	
		{
			Receive_Flag = 0;
			strcpy(rx_buf,USART_ReceiveString);
			memset(USART_ReceiveString,0,50);
			//串口消息判断
			//4.1温湿度
			if(strcmp(rx_buf,"d-t") == 0)
			{
				DHT_Read();
				int m1 = dat[0];//H,小数点前
				int m2 = dat[1];//H,小数点后
				int m3 = dat[2];
				int m4 = dat[3];
				printf("H:%d.%d%% T:%d.%d^C\r\n",m1,m2,m3,m4);
				TorH();
			}
			//4.2雨滴
			else if(strcmp(rx_buf,"rain") == 0)
			{
				int rval;
				ADvalue1 = Get_ADValue(ADC_Channel_7);
				rval = 99-((float)ADvalue1*3.3/4096)*2*99.0/5.0;
				printf("Flow intensity:%d%%\r\n",rval);
				rain();
			}
			//4.3光敏
			else if(strcmp(rx_buf,"light") == 0)
			{
				ADvalue2 = Get_ADValue(ADC_Channel_3);
				Delay_ms(100);
				int light_intensity = 99-((float)ADvalue2*3.3/4096)*2*99.0/5.0;
				printf("Light intensity:%d%%\r\n",light_intensity);
				light();
			}
			//4.4超声波
			else if(strcmp(rx_buf,"SonicDetection") == 0)
			{
				s_flag=1;
				sr04_uart();
			}
			//4.5.1舵机前进
			else if(strcmp(rx_buf,"gogo") == 0)
			{
				TIM_Cmd(TIM3, ENABLE);
				PWM_Setcompare1(1945);
				printf("Device Moving Forward\r\n");
			}
			//4.5.1舵机停止
			else if(strcmp(rx_buf,"stop") == 0)
			{
				TIM_Cmd(TIM3, DISABLE);
				printf("Device Stopping\r\n");
			}
			//4.6获取所有信息
			else if(strcmp(rx_buf,"all") == 0)
			{
				read_all();	
			}
			//4.7摄像头开启
			else if(strcmp(rx_buf,"movie") == 0)
			{
				Usart_SendString(USART1,"start\r\n");
			}
			//4.8碰撞检测
			else if(strcmp(rx_buf,"collide") == 0)
			{
				barricade_detection();
			}
			//错误指令判断
			else
			{
				printf("Instructions Warning\r\n");
				//printf("You Instructions is:%s\r\n",rx_buf);
			}
		}
		//无指令状态
		else
		{
			//正常状态提示
			show();
		}
		//4.6超声波按键中断触发,不做串口发送
//		while(s_flag==1)
//		{
//			sr04_lcd();
//		}
	}
}
